package bgu.spl.mics.application.objects;

import java.util.Collection;
import java.util.LinkedList;
import java.util.Queue;

/**
 * Passive object representing a single CPU.
 * Add all the fields described in the assignment as private fields.
 * Add fields and methods to this class as you see fit (including public methods and constructors).
 */
public class CPU {
    private int core;
    private Queue<DataBatch> data;
    private Cluster cluster;


    public CPU(int core,Cluster cluster){
        this.core = core;
        this.cluster = cluster;
        data = new LinkedList<>();
    }

    public DataBatch getDataBatch(){
        return data.peek();
    }

    public DataBatch processDataBatch(DataBatch dataBatch){
        dataBatch.setIsProcessed(DataBatch.status.Yes);
        return dataBatch;
    }



}

