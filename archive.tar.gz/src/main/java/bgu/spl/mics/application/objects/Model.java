package bgu.spl.mics.application.objects;

/**
 * Passive object representing a Deep Learning model.
 * Add all the fields described in the assignment as private fields.
 * Add fields and methods to this class as you see fit (including public methods and constructors).
 */
public class Model {
    private String name; // Model name
    private Data data; //the data the model should train on
    private Student student;// the student who created the model
    enum Status {
        PreTrained, Training, Trained, Tested
    }
    private Status myStatus;
    enum Result {
        None, Good, Bad // None for model not tested
    }
    private Result myResult;

    public Data getData() {
        return data;
    }

    public Status getMyStatus() {
        return myStatus;
    }

    public void setMyStatus(Status myStatus) {
        this.myStatus = myStatus;
    }
}
