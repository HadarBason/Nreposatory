package bgu.spl.mics.application.objects;

import java.util.LinkedList;
import java.util.Queue;

import static bgu.spl.mics.application.objects.Model.Status.Tested;
import static bgu.spl.mics.application.objects.Model.Status.Trained;

/**
 * Passive object representing a single GPU.
 * Add all the fields described in the assignment as private fields.
 * Add fields and methods to this class as you see fit (including public methods and constructors).
 */
public class GPU {
    /**
     * Enum representing the type of the GPU.
     * 3090- 1 tick , 32 batches
     * 2080- 2 ticks , 16 batches
     * 1080- 4 ticks , 8 batches
     */
    enum Type {RTX3090, RTX2080, GTX1080}

    private Type type;
    private Model model; // the model the GPU is currently working on
    private Cluster cluster;
    private Queue<DataBatch> unprocessed;
    private Queue<DataBatch> processed;

    public GPU (Type type,Cluster cluster){
        this.type = type;
        this.cluster = cluster;
        this.model=null;
        this.unprocessed = new LinkedList<DataBatch>();
        this.processed = new LinkedList<DataBatch>();
    }

    public Queue<DataBatch> getUnprocessed() {
        return unprocessed;
    }

    public Model getModel() {
        return model;
    }

    public void setModel(Model model) {
        this.model = model;
    }

    public void setDataBatches (){
        for(int j =0; j < model.getData().getSize(); j+=1000){
            unprocessed.add(new DataBatch(model.getData(),j));
        }
    }

    public Model testModelEvent (){ // send the model to testing
        model.setMyStatus(Tested);
        return model;
    }
    public Model trainModelEvent (){ // send model to training
        model.setMyStatus(Trained);
        return model;
    }



}
