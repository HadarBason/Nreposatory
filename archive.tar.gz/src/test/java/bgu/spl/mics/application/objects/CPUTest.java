package bgu.spl.mics.application.objects;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class CPUTest {

    private CPU cpu1;
    private Cluster cluster = new Cluster();

    @BeforeEach
    void setUp() { cpu1=new CPU(32,cluster);
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void getDataBatch() {
        // see bellow
    }

    @Test
    void processDataBatch() {
        assertEquals(cpu1.getDataBatch().getIsProcessed(), DataBatch.status.No);
        cpu1.processDataBatch(cpu1.getDataBatch());
        assertEquals(cpu1.getDataBatch().getIsProcessed(), DataBatch.status.Yes);
    }
}