package bgu.spl.mics.application.objects;

/**
 * Passive object representing a data used by a model.
 * Add fields and methods to this class as you see fit (including public methods and constructors).
 */

public class DataBatch {
    private Data data; // the data the batch belong to
    private int startIndex; // the index of the first sample in the batch
    enum status {Yes, No}
    private status isProcessed;

    public DataBatch(Data data,int startIndex){
        this.data = data;
        this.startIndex = startIndex;
        this.isProcessed = status.No;
    }

    public status getIsProcessed() {
        return isProcessed;
    }

    public void setIsProcessed (status S){
        this.isProcessed = S;
    }
    
}
