package bgu.spl.mics;

import bgu.spl.mics.application.messages.TestModelEvent;
import bgu.spl.mics.application.services.GPUService;
import bgu.spl.mics.application.services.StudentService;
import bgu.spl.mics.example.messages.ExampleBroadcast;
import bgu.spl.mics.example.messages.ExampleEvent;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class MessageBusImplTest {
    private MessageBus m;
    @BeforeEach
    void setUp() { m= new MessageBusImpl();
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void subscribeEvent() {
        // tested at  sendEvent bellow
    }

    @Test
    void subscribeBroadcast() {
        // tested at  sendBroadcast bellow
    }

    @Test
    void complete() {
        ExampleEvent t = new ExampleEvent("din");
        MicroService gpu1 = new GPUService("GPU1");
        m.register(gpu1);
        m.subscribeEvent(ExampleEvent.class,gpu1);
        Future f = m.sendEvent(t);
        assertNotNull(f);
        m.complete(t,"yes");
        assertTrue(f.isDone());
    }

    @Test
    void sendBroadcast() {
        ExampleBroadcast d = new ExampleBroadcast("din");
        MicroService gpu1 = new GPUService("GPU1");
        MicroService gpu2 = new GPUService("GPU2");
        m.register(gpu1);
        m.register(gpu2);
        m.subscribeBroadcast(ExampleBroadcast.class,gpu1);
        m.subscribeBroadcast(ExampleBroadcast.class,gpu2);
        m.sendBroadcast(d);
        try{
            Message msg1 = m.awaitMessage(gpu1);
            assertEquals(d,msg1);
            Message msg2 = m.awaitMessage(gpu1);
            assertEquals(d,msg2);
        }
        catch (InterruptedException e){
            fail("awaitMessage fail");
        }
    }

    @Test
    void sendEvent() {
        ExampleEvent t = new ExampleEvent("din");
        MicroService gpu1 = new GPUService("GPU1");
        m.register(gpu1);
        m.subscribeEvent(ExampleEvent.class,gpu1);
        Future f = m.sendEvent(t);
        assertNotNull(f);
        try{
            Message msg = m.awaitMessage(gpu1);
            assertEquals(t,msg);
        }
        catch (InterruptedException e){
            fail("awaitMessage fail");
        }

    }

    @Test
    void register() {
        assertNull(m.sendEvent(new ExampleEvent("hi")));
        MicroService gpu1 = new GPUService("gpu1");
        m.register(gpu1);
        m.subscribeEvent(ExampleEvent.class,gpu1);
        assertNotNull(m.sendEvent(new ExampleEvent("hi")));
    }

    @Test
    void unregister() {
        MicroService gpu1 = new GPUService("gpu1");
        m.register(gpu1);
        m.subscribeEvent(ExampleEvent.class,gpu1);
        assertNotNull(m.sendEvent(new ExampleEvent("hi")));
        m.unregister(gpu1);
        assertNull(m.sendEvent(new ExampleEvent("hi")));
    }

    @Test
    void awaitMessage() {
        ExampleEvent t = new ExampleEvent("din");
        MicroService gpu1 = new GPUService("GPU1");
        m.register(gpu1);
        m.subscribeEvent(ExampleEvent.class,gpu1);
        try{
            Message msg = m.awaitMessage(gpu1);
            assertEquals(t,msg);
        }
        catch (InterruptedException e){
            fail("awaitMessage fail");
        }
    }
}