package bgu.spl.mics;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.concurrent.TimeUnit;

import static org.junit.jupiter.api.Assertions.*;

class FutureTest {

    private Future<String> f;

    @BeforeEach
    void setUp() { f  = new Future<>(); }

    @AfterEach
    void tearDown() {
    }

    @Test
    void get() {
        assertFalse(f.isDone());
        //assertNull(f.get(1,TimeUnit.MILLISECONDS));
        f.resolve("yes");
        assertTrue(f.isDone());
        assertEquals("yes", f.get());
    }

    @Test
    void resolve() {
        assertFalse(f.isDone());
        f.resolve("yes");
        assertTrue(f.isDone());
        assertEquals("yes", f.get());

    }

    @Test
    void isDone() {
        assertFalse(f.isDone());
        f.resolve("yes");
        assertTrue(f.isDone());
    }

    @Test
    void testGet() {
        assertFalse(f.isDone());
        long time1 = System.currentTimeMillis();
        assertNull(f.get(1024, TimeUnit.MILLISECONDS));
        try{
            Thread.sleep(1024);
        }
        catch (Exception e) {
            fail("fail to sleep");
        }
        long time2 = System.currentTimeMillis();
        assertTrue(time2-time1 >= 1024);
        assertFalse(f.isDone());
        f.resolve("yes");
        assertEquals("yes", f.get(1300, TimeUnit.MILLISECONDS));
        //assertEquals(null , f.get(1024, TimeUnit.MILLISECONDS));
    }
}