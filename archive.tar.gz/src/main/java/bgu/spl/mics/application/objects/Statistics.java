package bgu.spl.mics.application.objects;

import java.util.Set;

public class Statistics {
    private Set<String> modelsNames;
    private long totalData;
    private long CPUTime;
    private long GPUTime;

}
