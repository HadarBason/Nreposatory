package bgu.spl.mics.application.objects;

import bgu.spl.mics.application.messages.TrainModelEvent;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static bgu.spl.mics.application.objects.GPU.Type.RTX3090;
import static bgu.spl.mics.application.objects.Model.Status.*;
import static org.junit.jupiter.api.Assertions.*;

class GPUTest {
    private GPU gpu1;
    private Cluster cluster = new Cluster();
    @BeforeEach

    void setUp() { gpu1 = new GPU(RTX3090,cluster);
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void getModel(){
        // see bellow
    }
    @Test
    void setModel() {
        assertNull(gpu1.getModel());
        gpu1.setModel(new Model());
        assertNotNull(gpu1.getModel());
    }

    @Test
    void setDataBatches() {
        assertEquals(gpu1.getUnprocessed().size(),0);
        gpu1.setModel(new Model());
        gpu1.setDataBatches();
        assertNotEquals(gpu1.getUnprocessed().size(),0);
    }

    @Test
    void testModelEvent() {
        gpu1.setModel(new Model());
        gpu1.getModel().setMyStatus(PreTrained);
        gpu1.testModelEvent();
        assertEquals(gpu1.getModel().getMyStatus(),Tested);
    }

    @Test
    void trainModelEvent() {
        gpu1.setModel(new Model());
        gpu1.getModel().setMyStatus(PreTrained);
        gpu1.trainModelEvent();
        assertEquals(gpu1.getModel().getMyStatus(),Trained);
    }




}